export class dashboardModel {
    errorLogs: string[];
    sessionId: number;
    processlogs: string[];
    processName: string;
    jobs: string[];
    totalCnt: number;
    successCnt: number;
    inprogressCnt: number;
    issuesCnt: number;
    filterData: string[];
    childJobs: string[];
    filteredJobs:string[];
}