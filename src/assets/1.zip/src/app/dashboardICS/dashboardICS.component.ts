import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { NgbPopoverConfig } from '@ng-bootstrap/ng-bootstrap';
import { dashboardModel } from './dashboardICS.model';
import { Chart } from 'chart.js';
import { Http, RequestOptions, Response, URLSearchParams, Headers, ResponseContentType, BrowserXhr } from '@angular/http';
import { environment } from '../../environments/environment';
import {MediaMatcher} from '@angular/cdk/layout';

const API_URL = environment.apiUrl;
/**
 * @title Expansion panel as accordion
 */
@Component({
  selector: 'app-dashboardICS',
  templateUrl: './dashboardICS.component.html',
  styleUrls: ['./dashboardICS.component.css']
})
export class DashboardComponent implements OnInit {
  public dashboardModel: dashboardModel;
  private _mobileQueryListener: () => void;
  mobileQuery: MediaQueryList;
  statusFilter: string[] = [];
  systemFilter: string[] = [];
  frequencyFilter: string[] = [];
  hasChild: number = 0;
  step = 1;

  constructor(private httpService: HttpClient, config: NgbPopoverConfig, public http: Http, 
    changeDetectorRef: ChangeDetectorRef, media: MediaMatcher) {
    this.dashboardModel = new dashboardModel();
    // customize default values of popovers used by this component tree
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    config.placement = ["left"];
    config.triggers = 'hover';
    config.container = "body";
  }
  memChart = undefined;
  ngOnInit() {

    const doughnutGraphData = {
      datasets: [{
        borderWidth:[0,0],
        data: [],
        backgroundColor: ['#32CD32', '#FF0000'],
      }],

    };

    const ctx = document.getElementById('mChart');

    var options = {
      cutoutPercentage:20,
      tooltips: {
        enabled: false
      }
    };

    this.memChart = new Chart(ctx, {
      type: 'doughnut',
      data: doughnutGraphData,
      options: options
    });
    /**
     *  Api service call to get list of jobs
     */
    const restServiceCall = API_URL + '/GetAllJobsDetails';
    let data: any[];
    this.http.get(restServiceCall)
      .subscribe(res => {
        data = res.json();
      }, (err: any) => {
        //to be implemented
      }
      );

    this.httpService.get('/assets/json/test.json').subscribe(
      data => {
        this.dashboardModel.jobs = data["InterfaceJobs"] as string[];	 // FILL THE ARRAY WITH DATA.
        this.dashboardModel.filteredJobs = data["InterfaceJobs"] as string[];
        this.dashboardModel.totalCnt = data["TotalJobs"] as number;
        this.dashboardModel.successCnt = data["SuccessCount"] as number;
        this.dashboardModel.issuesCnt = data["IssuesCount"] as number;
        this.dashboardModel.filterData = data["Filters"] as string[];
        this.dashboardModel.inprogressCnt = this.dashboardModel.totalCnt - this.dashboardModel.successCnt - this.dashboardModel.issuesCnt;

        this.memChart.data.datasets.forEach((dataset) => {
          dataset.data.push(this.dashboardModel.successCnt);
          dataset.data.push(this.dashboardModel.issuesCnt);
        });
        this.memChart.update(0);
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep(jobName: string, jobFrequency: string) {
    if (jobFrequency != null && jobName != null) {
      if (this.step != 2) {
        if (jobFrequency == 'F') {
          this.childInstancesDetails(jobName);
          this.setStep(2);
          this.hasChild = 1;
        }
        else {

          this.processLogdetails(jobName);
          this.hasChild = 0;
          this.setStep(3);
        }
      }
      else {
        this.processLogdetails(jobName);
        this.setStep(3);
      }
    }
    //this.step++;
  }

  childInstancesDetails(jobName: string) {
    /**
         *  Api service call to get list of childinstances using jobName
         */
    const restServiceCall = API_URL + '/GetChildInstances/' + jobName;
    let data: any[];
    const params: URLSearchParams = new URLSearchParams();
    params.set('JobName', jobName);
    this.http.get(restServiceCall, { params: params })
      .subscribe(res => {
        data = res.json();
      }, (err: any) => {
        //error handling to be implemented
      }
      );

    this.httpService.get('/assets/json/childs.json').subscribe(
      data => {
        this.dashboardModel.childJobs = data as string[];
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
  }

  processLogdetails(jobName: string) {
    this.dashboardModel.processName = jobName;
    /**
             *  Api service call to process log details
             */
    const restServiceCall = API_URL + '/GetLogsDetails/' + jobName;
    let data: any[];
    const params: URLSearchParams = new URLSearchParams();
    params.set('JobName', jobName);
    this.http.get(restServiceCall, { params: params })
      .subscribe(res => {
        data = res.json();
      }, (err: any) => {
        //error handling to be implemented
      }
      );

    this.httpService.get('/assets/json/logs.json').subscribe(
      data => {
        data["ProcessLogs"].forEach(item => {
          if (item.pl_status == 'B')
            item.pl_status = "Started";
          if (item.pl_status == 'E')
            item.pl_status = "Ended";
          if (item.pl_status == 'F')
            item.pl_status = "Failure";
        });
        this.dashboardModel.processlogs = data["ProcessLogs"] as string[];
        this.dashboardModel.sessionId = data["ProcessLogs"][0].pl_session_id as number;
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
  }

  errorLog(sessionId: Number) {
    /**
             *  Api service call to error log details
             */
    const restServiceCall = API_URL + '/GetLogsDetails/' + sessionId;
    let data: any[];
    this.http.get(restServiceCall)
      .subscribe(res => {
        data = res.json();
      }, (err: any) => {
        //error handling to be implemented
      }
      );

    this.httpService.get('/assets/json/logs.json').subscribe(
      data => {
        this.dashboardModel.errorLogs = data["ErrorLogs"] as string[];
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
    this.setStep(4);
  }

  filterSelected(event: Event) {
    let selectedOption = event["option"] as object;
    let selectedValue = selectedOption["value"] as string;
    let isSelected = selectedOption["_selected"] as boolean;
    let filter = this.dashboardModel.filterData.filter(f => f["children"].indexOf(selectedValue) != -1);

    if (isSelected) {
      if (filter[0]["parent"] == "STATUS") {
        if (selectedValue == 'Success')
          selectedValue = 'Ended';
        else if (selectedValue == 'InProgress')
          selectedValue = 'Started';
        this.statusFilter.push(selectedValue);
      }
      else if (filter[0]["parent"] == "FREQUENCY") {
        if (selectedValue == 'MULTIPLE')
          selectedValue = 'F';
        if (selectedValue == 'NON-MULTIPLE')
          selectedValue = 'D';
        this.frequencyFilter.push(selectedValue);
      }
      else {
        this.systemFilter.push(selectedValue);
      }
    }
    else {
      if (filter[0]["parent"] == "STATUS") {
        if (selectedValue == 'Success')
          selectedValue = 'Ended';
        else if (selectedValue == 'InProgress')
          selectedValue = 'Started';
        let arrayIndex = this.statusFilter.indexOf(selectedValue);
        this.statusFilter.splice(arrayIndex, 1);
      }
      else if (filter[0]["parent"] == "FREQUENCY") {
        if (selectedValue == 'MULTIPLE')
          selectedValue = 'F';
        if (selectedValue == 'NON-MULTIPLE')
          selectedValue = 'D';
        let arrayIndex = this.frequencyFilter.indexOf(selectedValue);
        this.frequencyFilter.splice(arrayIndex, 1);
      }
      else {
        let arrayIndex = this.systemFilter.indexOf(selectedValue);
        this.systemFilter.splice(arrayIndex, 1);
      }
    }

    if (this.dashboardModel.jobs != null) {
      let testJobs = this.dashboardModel.jobs;
      if (this.statusFilter.length > 0) {
        testJobs = testJobs.filter
          (e => (this.statusFilter.indexOf(e["status"]) != -1));
      }
      if (this.frequencyFilter.length > 0) {
        testJobs = testJobs.filter
          (e => (this.frequencyFilter.indexOf(e["frequency"]) != -1));
      }
      if (this.systemFilter.length > 0) {
        testJobs = testJobs.filter
          (e => (this.systemFilter.indexOf(e["source"]) != -1)
            || (this.systemFilter.indexOf(e["target"]) != -1));
      }
      this.dashboardModel.filteredJobs = testJobs;
    }
    this.setStep(1);
  }
}
