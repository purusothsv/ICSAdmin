import { CommonModule }   from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatExpansionModule, MatSidenavModule,MatIconModule,MatButtonModule,MatListModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http'; 
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { DashboardComponent }    from './dashboardICS.component';
import { DashboardRoutingModule }    from './dashboardICS-routing.module';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,    
    MatListModule,
    HttpModule,
    HttpClientModule,
    NgbModule.forRoot()
  ],
  declarations: [
    DashboardComponent
  ]
})
export class DashboardModule {}
