import { DashboardComponent } from './dashboardICS/dashboardICS.component';


export class icon {
    constructor(
      public id: number,
      public name: string) { }
  }