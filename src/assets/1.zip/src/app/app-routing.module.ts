import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent }    from './dashboardICS/dashboardICS.component';
import { PageNotFoundComponent }    from './not-found.component';

const appRoutes: Routes = [
    {
      path: 'dashboard',
      component: DashboardComponent,
    },
    { path: '',   redirectTo: '/dashboard', pathMatch: 'full' },
    { path: '**', component: PageNotFoundComponent }
];

@NgModule({
    imports: [
      RouterModule.forRoot(
        appRoutes,
        {
          enableTracing: true, // <-- debugging purposes only
  
        }
      )
    ],
    exports: [
      RouterModule
    ]
  })
  export class AppRoutingModule { }
  